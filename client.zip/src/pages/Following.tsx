import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Plus, Star, Users } from "lucide-react";
import { useLocation } from "wouter";

interface FollowedTeam {
  id: number;
  name: string;
  logoUrl: string;
  game: string;
  bgColor: string;
  nextMatch?: { opponent: string; date: string; isHome: boolean };
}

const DEMO_TEAMS: FollowedTeam[] = [
  {
    id: 5, name: "FaZe", logoUrl: "https://upload.wikimedia.org/wikipedia/en/4/46/FaZe_Clan_%282017%29.png",
    game: "CS2", bgColor: "#7f1d1d",
    nextMatch: { opponent: "Team Vitality", date: "Sat, 15 Mar at 8:00 PM", isHome: false }
  },
  {
    id: 9, name: "Team Liquid", logoUrl: "https://upload.wikimedia.org/wikipedia/en/4/46/Team_Liquid_logo_%282019%29.png",
    game: "Dota 2", bgColor: "#0c4a6e",
    nextMatch: { opponent: "Team Falcons", date: "Sun, 16 Mar at 6:00 PM", isHome: true }
  },
  {
    id: 3, name: "FURIA", logoUrl: "https://upload.wikimedia.org/wikipedia/en/0/0f/FURIA_Esports_logo.png",
    game: "Valorant", bgColor: "#1c1917",
    nextMatch: { opponent: "LOUD", date: "Fri, 14 Mar at 9:00 PM", isHome: false }
  },
  {
    id: 1, name: "Gentle Mates", logoUrl: "https://ui-avatars.com/api/?name=GM&background=6d28d9&color=fff&bold=true&size=200&font-size=0.5",
    game: "Valorant", bgColor: "#3b0764",
    nextMatch: { opponent: "BBL Esports", date: "Sat, 15 Mar at 7:00 PM", isHome: true }
  },
  {
    id: 7, name: "Acend", logoUrl: "https://ui-avatars.com/api/?name=Acend&background=7e22ce&color=fff&bold=true&size=200&font-size=0.33",
    game: "CS2", bgColor: "#2e1065",
    nextMatch: { opponent: "Nemesis", date: "Mon, 17 Mar at 5:00 PM", isHome: false }
  },
  {
    id: 6, name: "Monte", logoUrl: "https://ui-avatars.com/api/?name=Monte&background=1a56db&color=fff&bold=true&size=200&font-size=0.33",
    game: "CS2", bgColor: "#1e3a8a",
    nextMatch: { opponent: "Acend", date: "Mon, 17 Mar at 5:00 PM", isHome: true }
  },
];

type Tab = "teams" | "players";

export default function FollowingPage() {
  const [tab, setTab] = useState<Tab>("teams");
  const [, navigate] = useLocation();

  const DEMO_PLAYERS = [
    { id: 1, name: "ZywOo", team: "Team Vitality", game: "CS2", role: "Rifler", color: "#f5a623" },
    { id: 2, name: "Faker", team: "T1", game: "League of Legends", role: "Mid", color: "#c69b3a" },
    { id: 3, name: "Gumayusi", team: "Free Agent", game: "League of Legends", role: "ADC", color: "#ef4444" },
    { id: 4, name: "aspas", team: "MIBR", game: "Valorant", role: "Duelist", color: "#059669" },
  ];

  return (
    <AppLayout>
      <div className="flex flex-col w-full">
        {/* Header */}
        <div className="px-5 pt-6 pb-3">
          <div className="flex items-center justify-between mb-5">
            <h1 className="font-display font-bold text-3xl text-white">Following</h1>
            <div className="flex items-center gap-2">
              <button
                className="px-4 py-1.5 rounded-full bg-white/8 border border-white/15 text-sm font-semibold text-white/80 hover:bg-white/15 transition-colors"
                data-testid="button-edit-following"
              >
                Edit
              </button>
              <button
                className="w-8 h-8 rounded-full bg-white/8 border border-white/15 flex items-center justify-center hover:bg-white/15 transition-colors"
                data-testid="button-add-following"
                onClick={() => navigate("/leagues")}
              >
                <Plus className="w-4 h-4 text-white/80" />
              </button>
            </div>
          </div>

          {/* Tab Switcher */}
          <div className="flex gap-6 border-b border-white/10 pb-0">
            {(["teams", "players"] as Tab[]).map(t => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`pb-3 text-sm font-bold capitalize transition-all border-b-2 -mb-px ${
                  tab === t
                    ? "text-white border-white"
                    : "text-white/40 border-transparent hover:text-white/60"
                }`}
                data-testid={`tab-${t}`}
              >
                {t === "teams" ? "Teams" : "Players"}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto pb-24 px-4 pt-4">
          {tab === "teams" ? (
            <div className="grid grid-cols-2 gap-3">
              {DEMO_TEAMS.map(team => (
                <TeamCard key={team.id} team={team} />
              ))}
            </div>
          ) : (
            <div className="space-y-3">
              {DEMO_PLAYERS.map(player => (
                <PlayerCard key={player.id} player={player} />
              ))}
              <div className="flex flex-col items-center py-10 text-white/30">
                <Users className="w-8 h-8 mb-2 opacity-40" />
                <p className="text-sm">Follow players to track them here</p>
                <button
                  onClick={() => navigate("/search")}
                  className="mt-3 px-4 py-2 rounded-full bg-primary/20 border border-primary/30 text-primary text-sm font-semibold"
                >
                  Find Players
                </button>
              </div>
            </div>
          )}

          {tab === "teams" && DEMO_TEAMS.length === 0 && (
            <div className="flex flex-col items-center py-20 text-white/30">
              <Star className="w-10 h-10 mb-3 opacity-40" />
              <p className="text-sm">You're not following any teams yet</p>
              <button
                onClick={() => navigate("/leagues")}
                className="mt-4 px-5 py-2.5 rounded-full bg-primary/20 border border-primary/30 text-primary text-sm font-semibold"
              >
                Browse Teams
              </button>
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  );
}

function TeamCard({ team }: { team: FollowedTeam }) {
  return (
    <div
      className="rounded-2xl p-4 flex flex-col justify-between min-h-[160px] relative overflow-hidden cursor-pointer hover:opacity-90 transition-opacity"
      style={{ backgroundColor: team.bgColor }}
      data-testid={`card-team-${team.id}`}
    >
      {/* Background gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent pointer-events-none" />

      {/* Team Logo */}
      <div className="w-10 h-10 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center overflow-hidden mb-2">
        <img src={team.logoUrl} alt={team.name} className="w-full h-full object-contain p-1" />
      </div>

      {/* Team Name */}
      <div>
        <p className="font-bold text-white text-base leading-tight mb-3">{team.name}</p>

        {/* Next Match */}
        {team.nextMatch && (
          <div className="space-y-0.5">
            <div className="flex items-center gap-1 text-white/70">
              <span className="text-[10px]">{team.nextMatch.isHome ? "⇒" : "✈"}</span>
              <span className="text-[11px] font-medium">{team.nextMatch.opponent}</span>
            </div>
            <p className="text-[10px] text-white/50">{team.nextMatch.date}</p>
          </div>
        )}
      </div>
    </div>
  );
}

function PlayerCard({ player }: { player: { id: number; name: string; team: string; game: string; role: string; color: string } }) {
  return (
    <div
      className="flex items-center gap-4 p-4 rounded-2xl border border-white/8 bg-white/4 hover:bg-white/7 transition-colors cursor-pointer"
      data-testid={`card-player-${player.id}`}
    >
      <div
        className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-sm flex-shrink-0"
        style={{ backgroundColor: player.color + "33", border: `1px solid ${player.color}55` }}
      >
        <span style={{ color: player.color }}>{player.name.substring(0, 2).toUpperCase()}</span>
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-bold text-white text-sm">{player.name}</p>
        <p className="text-xs text-white/50">{player.team} · {player.game}</p>
        <p className="text-[10px] text-white/35 mt-0.5">{player.role}</p>
      </div>
      <Star className="w-4 h-4 text-primary fill-primary flex-shrink-0" />
    </div>
  );
}
