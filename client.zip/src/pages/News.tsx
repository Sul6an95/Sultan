import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { ArrowLeft, Clock, Trophy, Users, DollarSign, Zap, Star } from "lucide-react";

interface Article {
  id: number;
  title: string;
  summary: string;
  content: string;
  category: "tournament" | "transfer" | "sponsorship" | "announcement";
  game: string;
  date: string;
  readTime: string;
}

const NEWS_ARTICLES: Article[] = [
  {
    id: 1,
    title: "Team Vitality يتوّج بلقب IEM Kraków 2026 بعد إقصاء FURIA 3-1",
    summary: "حقّق الفريق الفرنسي Team Vitality بطولة IEM Kraków 2026 للـ CS2 بعد تفوّقه على FURIA البرازيلي بنتيجة 3-1 في مباراة نهائية مثيرة.",
    content: `شهد ملعب Tauron Arena في مدينة كراكوف البولندية نهائياً مثيراً جمع الفريقين الكبيرين Team Vitality وFURIA، حيث أثبت الفريق الفرنسي تفوّقه وأحكم قبضته على البطولة بنتيجة حاسمة 3-1.

قاد النجم البلجيكي ZywOo الفريق بأداء خارق طوال البطولة، وأُعلن عنه لاعباً للمباراة الأكثر قيمة (MVP) بعد أداء رائع في الخرائط الفاصلة. تُعدّ هذه البطولة ثاني ألقاب IEM لـ Team Vitality في أقل من عام.

أمّا FURIA البرازيلي فقد أثبت قيمته بالوصول إلى النهائي، لكنّه عجز عن مقاومة التشكيلة الأوروبية القوية. الجدير بالذكر أن FURIA كان قد توّج ببطوليتَي IEM Chengdu وBLAST Rival Fall في النصف الأخير من عام 2025.

البطولة شهدت أيضاً تألّق النجم الجديد bodyy الذي يبدو مرشّحاً قوياً لجوائز نهاية الموسم.`,
    category: "tournament",
    game: "Counter-Strike 2",
    date: "8 مارس 2026",
    readTime: "3 دقائق",
  },
  {
    id: 2,
    title: "T1 يُحقّق اللقب الأسطوري في Worlds 2025 وGumayusi يُتوَّج أفضل لاعب في النهائي",
    summary: "أسدل T1 الكوري الجنوبي الستار على بطولة Worlds 2025 بلقبٍ تاريخي جديد، فيما نال المهاجم Gumayusi جائزة أفضل لاعب في النهائي.",
    content: `في ليلةٍ سيخلّدها تاريخ الـ League of Legends، رفع فريق T1 الكوري الجنوبي كأس Worlds 2025 وسط هتافات الجماهير بعد رحلةٍ مليئة بالإثارة والتوتر.

أبدع المهاجم Gumayusi طوال مباريات النهائي بأداءٍ فنّي رفيع المستوى استحق عليه جائزة MVP بعد تسجيله أرقاماً فلكية في الخسائر وتعطيله الدائم للخصم. كان Gumayusi محلّ جدلٍ واسع قبيل البطولة، إذ تعرّض لانتقادات بسبب تراجع مستواه، لكنّه ردّ بالأفعال على أرض الملعب.

وفي مفاجأة صدمت مجتمع اللعبة، أعلن Gumayusi بُعيد تتويجه بالبطولة مغادرته لـ T1 بحثاً عن تجربةٍ جديدة، مما يُشكّل خسارة جسيمة للفريق الأكثر تتويجاً في تاريخ Worlds.`,
    category: "tournament",
    game: "League of Legends",
    date: "5 مارس 2026",
    readTime: "4 دقائق",
  },
  {
    id: 3,
    title: "NRG يُهيمن على VALORANT Champions 2025 ويُتوَّج بطلاً للعالم",
    summary: "فريق NRG الأمريكي يُحقّق حلم الفوز بـ VALORANT Champions 2025 في مسابقةٍ احتضنت أفضل فرق العالم.",
    content: `احتفى الجمهور المحتشد بفريق NRG وهو يرفع كأس VALORANT Champions 2025، ليُسدل الستار على موسمٍ مليءٍ بالإثارة والمنافسة الشديدة.

جسّد الفريق مفهوم العمل الجماعي بأجلى صوره؛ إذ أسهم كل لاعب بدوره في صنع هذا الإنجاز التاريخي. وقد بلغت مواجهاتهم مع الفرق الآسيوية والأوروبية درجةً عاليةً من التشويق، مما رسم صورة قاتمة حول احتكار أمريكا الشمالية لهذا اللقب.

رأى كثير من المحللين أن أسلوب لعب NRG تطوّر تطوراً ملحوظاً خلال الموسم، لا سيّما على صعيد التنسيق الجماعي والتكتيكات الهجومية. وتبقى هذه البطولة شهادةً على مكانة NRG بوصفه أحد أعتى فرق الـ VALORANT في العالم.`,
    category: "tournament",
    game: "Valorant",
    date: "1 مارس 2026",
    readTime: "3 دقائق",
  },
  {
    id: 4,
    title: "Team Falcons يفوز بـ Esports World Cup 2025 للمرة الثانية على التوالي بجائزة 7 ملايين دولار",
    summary: "الفريق السعودي Team Falcons يُعيد الكرّة ويفوز بلقب Esports World Cup للعام الثاني على التوالي بجائزةٍ ضخمة بلغت 7 ملايين دولار.",
    content: `كتب الفريق السعودي Team Falcons اسمه بحروفٍ من ذهب في سجلات الرياضة الإلكترونية، بعد أن أصبح الفريق الأول في تاريخ Esports World Cup يتوّج بالبطولة عامَين متتاليَين.

في بطولةٍ ضمّت أكثر من 22 لعبة إلكترونية وفرقاً من شتى أنحاء العالم، تمكّن Falcons من تجميع نقاط Club Championship الكافية لانتزاع اللقب العام برصيدٍ يتخطى منافسيه بفارقٍ واضح.

لم يتوقف الأمر عند هذا الحدّ؛ ففريق Falcons توّج بطلاً في بطولة The International 2025 للـ Dota 2، مُسجّلاً بذلك إنجازاً مزدوجاً نادراً في عالم الإيسبورت. الجائزة الإجمالية لبطولة Esports World Cup 2025 تجاوزت 70 مليون دولار، وهو رقمٌ قياسي غير مسبوق في تاريخ الرياضة الإلكترونية.`,
    category: "tournament",
    game: "Dota 2",
    date: "25 فبراير 2026",
    readTime: "4 دقائق",
  },
  {
    id: 5,
    title: "JonahP ينضم إلى Sentinels في صفقة مفاجئة قُبيل انطلاق VCT 2026",
    summary: "انتقال صادم في عالم VALORANT؛ JonahP يغادر G2 Esports ليلتحق بـ Sentinels بعد أسابيع قليلة من انطلاق موسم VCT 2026 Americas.",
    content: `فجّر عالم VALORANT مفاجأةً كبيرة، حين أعلن كلٌّ من Sentinels وG2 Esports رسمياً انتقال اللاعب الأمريكي JonahP (Jonah Pulice) من المعسكر الأوروبي إلى الأمريكي قُبيل انطلاق موسم VCT 2026 Americas.

اللافت في هذه الصفقة أن JonahP كان جزءاً من تشكيلة G2 Esports، قبل أن تُقرّر الإدارة إجراء تعديلات على الروستر في اللحظات الأخيرة. الاتفاق نُفِّذ بسرعةٍ لافتة، ويُعدّ دليلاً على ديناميكية سوق انتقالات الـ VALORANT.

يُتوقّع من JonahP أن يُسهم في قلب موازين Sentinels بعد موسمٍ صعب، فيما تستعدّ Sentinels لبدء مشوارها في VCT 2026 Americas بتشكيلةٍ جديدة وطموحاتٍ أكبر.`,
    category: "transfer",
    game: "Valorant",
    date: "6 مارس 2026",
    readTime: "3 دقائق",
  },
  {
    id: 6,
    title: "100 Thieves تعود إلى CS2 برعاية Roobet وتشكيلة جديدة بالكامل",
    summary: "المنظمة الأمريكية المرموقة 100 Thieves تُعلن عودتها الرسمية إلى Counter-Strike 2 بعقد رعاية مع Roobet وإعادة بناء الفريق من الصفر.",
    content: `أعلنت منظمة 100 Thieves ذات الشهرة الواسعة عودتها الرسمية إلى ساحة Counter-Strike 2، بعد غيابٍ لفت إليه الأنظار. جاءت العودة محمّلةً بثلاثة مستجدات كبرى: عقد رعاية مع منصة Roobet، وإعادة بناء الروستر بالكامل، وخطة تنافسية طموحة للموسم.

عقد الرعاية مع Roobet يُعدّ من أبرز صفقات الرعاية في عالم الـ CS2 خلال عام 2026، إذ يمنح 100 Thieves الدعم المالي اللازم لاستقطاب أسماء لامعة.

التشكيلة الجديدة ما زالت طيّ الكتمان، غير أن المنظمة وعدت بالإعلان عن أسماء مفاجئة وقادرة على المنافسة في أرقى البطولات. مشجّعو 100 Thieves يتطلّعون بشوقٍ لرؤية ألوان المنظمة تعود للتألّق على خرائط CS2.`,
    category: "sponsorship",
    game: "Counter-Strike 2",
    date: "3 مارس 2026",
    readTime: "3 دقائق",
  },
  {
    id: 7,
    title: "Esports World Cup 2026 يُعلن عن جائزة تاريخية بقيمة 75 مليون دولار في الرياض",
    summary: "النسخة الثالثة من بطولة Esports World Cup ستُقام في الرياض بجائزةٍ ضخمة تتجاوز 75 مليون دولار وبمشاركة 22 لعبة إلكترونية.",
    content: `كشف الرياض إسبورت عن التفاصيل المبهرة لبطولة Esports World Cup 2026، التي ستُعقد بالعاصمة السعودية الرياض في الفترة من 6 يوليو حتى 23 أغسطس 2026.

المبلغ الإجمالي للجوائز يتخطى 75 مليون دولار، مُتجاوزاً بذلك رقم الـ 70 مليون دولار الذي سُجِّل في النسخة الماضية. البطولة ستحتضن 22 لعبة إلكترونية، من بينها CS2 وVALORANT وDota 2 وLeague of Legends وOverwatch 2 وغيرها.

هذا الإعلان يُعمّق مكانة المملكة العربية السعودية بوصفها وجهةً عالمية رائدة في مجال الإيسبورت، في إطار استراتيجية رؤية 2030 لتنويع مصادر الاقتصاد. التسجيل للفرق والبطاقات للجمهور سيبدأ قريباً عبر الموقع الرسمي.`,
    category: "announcement",
    game: "متعدد الألعاب",
    date: "28 فبراير 2026",
    readTime: "4 دقائق",
  },
];

const CATEGORY_STYLES: Record<Article["category"], { label: string; color: string; bg: string }> = {
  tournament: { label: "بطولات", color: "text-yellow-400", bg: "bg-yellow-500/20 border-yellow-500/30" },
  transfer: { label: "انتقالات", color: "text-blue-400", bg: "bg-blue-500/20 border-blue-500/30" },
  sponsorship: { label: "رعاية", color: "text-green-400", bg: "bg-green-500/20 border-green-500/30" },
  announcement: { label: "إعلانات", color: "text-primary", bg: "bg-primary/20 border-primary/30" },
};

const CATEGORY_ICONS: Record<Article["category"], typeof Trophy> = {
  tournament: Trophy,
  transfer: Users,
  sponsorship: DollarSign,
  announcement: Zap,
};

function ArticleCard({ article, onClick }: { article: Article; onClick: () => void }) {
  const cat = CATEGORY_STYLES[article.category];
  const Icon = CATEGORY_ICONS[article.category];

  return (
    <button
      onClick={onClick}
      className="w-full text-left bg-card border border-white/10 rounded-2xl p-5 hover:border-primary/40 hover:bg-card/80 transition-all group"
      data-testid={`card-article-${article.id}`}
    >
      <div className="flex items-center justify-between mb-3">
        <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[11px] font-bold ${cat.bg} ${cat.color}`}>
          <Icon className="w-3 h-3" />
          {cat.label}
        </div>
        <span className="text-[11px] text-white/40">{article.game}</span>
      </div>

      <h3 className="font-bold text-white text-sm leading-snug mb-2 group-hover:text-primary transition-colors line-clamp-2">
        {article.title}
      </h3>

      <p className="text-xs text-white/55 leading-relaxed line-clamp-2 mb-3">
        {article.summary}
      </p>

      <div className="flex items-center gap-3 text-[11px] text-white/40">
        <div className="flex items-center gap-1">
          <Clock className="w-3 h-3" />
          {article.date}
        </div>
        <span>•</span>
        <span>{article.readTime} قراءة</span>
      </div>
    </button>
  );
}

function ArticleView({ article, onBack }: { article: Article; onBack: () => void }) {
  const cat = CATEGORY_STYLES[article.category];
  const Icon = CATEGORY_ICONS[article.category];

  return (
    <div className="flex flex-col overflow-y-auto">
      <div className="sticky top-0 z-10 bg-background/90 backdrop-blur-sm border-b border-white/10 px-4 py-3">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm text-white/70 hover:text-white transition-colors"
          data-testid="button-back-news"
        >
          <ArrowLeft className="w-4 h-4" />
          رجوع للأخبار
        </button>
      </div>

      <div className="px-5 py-6 space-y-5">
        <div className="flex items-center gap-3">
          <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[11px] font-bold ${cat.bg} ${cat.color}`}>
            <Icon className="w-3 h-3" />
            {cat.label}
          </div>
          <span className="text-xs text-white/40">{article.game}</span>
        </div>

        <h1 className="font-bold text-white text-xl leading-snug">
          {article.title}
        </h1>

        <div className="flex items-center gap-3 text-xs text-white/40">
          <div className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5" />
            {article.date}
          </div>
          <span>•</span>
          <div className="flex items-center gap-1.5">
            <Star className="w-3.5 h-3.5" />
            {article.readTime} قراءة
          </div>
        </div>

        <div className="border-t border-white/10" />

        <div className="bg-primary/10 border border-primary/20 rounded-xl p-4">
          <p className="text-sm text-primary/90 leading-relaxed font-medium">
            {article.summary}
          </p>
        </div>

        <div className="space-y-4 pb-6">
          {article.content.split("\n\n").map((para, idx) => (
            <p key={idx} className="text-sm text-white/70 leading-relaxed">
              {para.trim()}
            </p>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function NewsPage() {
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [activeCategory, setActiveCategory] = useState<Article["category"] | "all">("all");

  const categories: { key: Article["category"] | "all"; label: string }[] = [
    { key: "all", label: "الكل" },
    { key: "tournament", label: "بطولات" },
    { key: "transfer", label: "انتقالات" },
    { key: "sponsorship", label: "رعاية" },
    { key: "announcement", label: "إعلانات" },
  ];

  const filtered = activeCategory === "all"
    ? NEWS_ARTICLES
    : NEWS_ARTICLES.filter(a => a.category === activeCategory);

  if (selectedArticle) {
    return (
      <AppLayout>
        <ArticleView article={selectedArticle} onBack={() => setSelectedArticle(null)} />
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="flex flex-col w-full">
        <div className="px-5 pt-5 pb-4 border-b border-white/10">
          <h1 className="font-display font-bold text-2xl text-primary mb-1">أخبار الإيسبورت</h1>
          <p className="text-xs text-white/50">آخر الأخبار والتقارير من عالم الرياضة الإلكترونية</p>
        </div>

        <div className="px-5 py-3 border-b border-white/10">
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {categories.map(cat => (
              <button
                key={cat.key}
                onClick={() => setActiveCategory(cat.key)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  activeCategory === cat.key
                    ? "bg-primary text-white"
                    : "bg-white/5 text-white/60 hover:text-white hover:bg-white/10"
                }`}
                data-testid={`button-filter-${cat.key}`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3 pb-24">
          {filtered.map(article => (
            <ArticleCard
              key={article.id}
              article={article}
              onClick={() => setSelectedArticle(article)}
            />
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
