import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import type { MatchWithRelations, Game, Team } from "@shared/schema";
import {
  LogIn, RefreshCw, Trash2, Pencil, Plus, Check, X,
  Shield, Gamepad2, Users, Trophy, Loader2, Tv2, Link2
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// ── helpers ──────────────────────────────────────────────────────────────────
const TOKEN_KEY = "rivox_admin_token";
const getToken = () => localStorage.getItem(TOKEN_KEY) || "";
const authHeader = () => ({ Authorization: `Bearer ${getToken()}` });

async function adminFetch(url: string, opts: RequestInit = {}) {
  const res = await fetch(url, {
    ...opts,
    headers: { "Content-Type": "application/json", ...authHeader(), ...(opts.headers || {}) },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: res.statusText }));
    throw new Error(err.message || "Error");
  }
  return res.json();
}

// ── Login ─────────────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }: { onLogin: (token: string) => void }) {
  const [pw, setPw] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const { toast } = useToast();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setErr("");
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: pw }),
      });
      if (!res.ok) { const d = await res.json(); throw new Error(d.message); }
      const { token } = await res.json();
      localStorage.setItem(TOKEN_KEY, token);
      onLogin(token);
      toast({ title: "تم الدخول بنجاح" });
    } catch (e: any) {
      setErr(e.message);
    } finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="flex items-center gap-3 mb-8 justify-center">
          <Shield className="w-8 h-8 text-primary" />
          <h1 className="text-2xl font-bold text-white">لوحة الإدارة</h1>
        </div>
        <form onSubmit={submit} className="bg-white/5 border border-white/10 rounded-2xl p-6 space-y-4">
          <div>
            <label className="text-sm text-white/60 mb-1 block">كلمة المرور</label>
            <input
              type="password"
              value={pw}
              onChange={e => setPw(e.target.value)}
              className="w-full bg-white/8 border border-white/12 rounded-xl px-4 py-3 text-white outline-none focus:border-primary transition"
              placeholder="••••••••"
              data-testid="input-admin-password"
              autoFocus
            />
          </div>
          {err && <p className="text-red-400 text-sm">{err}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-primary hover:bg-primary/80 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition"
            data-testid="button-admin-login"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <LogIn className="w-4 h-4" />}
            دخول
          </button>
        </form>
      </div>
    </div>
  );
}

// ── Stream URLs Input Component ───────────────────────────────────────────────
function StreamUrlsInput({ urls, onChange }: { urls: string[]; onChange: (urls: string[]) => void }) {
  const [newUrl, setNewUrl] = useState("");

  const add = () => {
    const trimmed = newUrl.trim();
    if (!trimmed || urls.includes(trimmed)) return;
    onChange([...urls, trimmed]);
    setNewUrl("");
  };

  const remove = (idx: number) => onChange(urls.filter((_, i) => i !== idx));

  const getPlatform = (url: string) => {
    if (url.includes("twitch")) return { label: "Twitch", color: "bg-purple-600/20 border-purple-500/30 text-purple-300" };
    if (url.includes("youtube")) return { label: "YouTube", color: "bg-red-600/20 border-red-500/30 text-red-300" };
    if (url.includes("afreeca") || url.includes("soop")) return { label: "AfreecaTV", color: "bg-blue-600/20 border-blue-500/30 text-blue-300" };
    if (url.includes("bilibili")) return { label: "bilibili", color: "bg-pink-600/20 border-pink-500/30 text-pink-300" };
    return { label: "بث مباشر", color: "bg-primary/15 border-primary/30 text-primary" };
  };

  return (
    <div className="space-y-2">
      <label className="text-white/50 text-xs mb-1 flex items-center gap-1.5">
        <Tv2 className="w-3.5 h-3.5" /> روابط البث (Twitch / YouTube / ...)
      </label>
      {/* Existing URLs */}
      {urls.map((url, idx) => {
        const { label, color } = getPlatform(url);
        return (
          <div key={idx} className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-xs ${color}`}>
            <span className="font-bold flex-shrink-0">{label}</span>
            <span className="flex-1 truncate opacity-70">{url}</span>
            <button onClick={() => remove(idx)} className="flex-shrink-0 hover:opacity-100 opacity-60">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
      {/* Add new URL */}
      <div className="flex gap-2">
        <input
          value={newUrl}
          onChange={e => setNewUrl(e.target.value)}
          onKeyDown={e => e.key === "Enter" && (e.preventDefault(), add())}
          placeholder="https://twitch.tv/... أو https://youtube.com/..."
          className="flex-1 bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-xs outline-none placeholder:text-white/30"
          data-testid="input-stream-url"
        />
        <button
          onClick={add}
          disabled={!newUrl.trim()}
          className="px-3 py-2 bg-primary/20 text-primary border border-primary/30 rounded-lg text-xs font-bold hover:bg-primary/30 disabled:opacity-40 transition flex items-center gap-1"
          data-testid="button-add-stream-url"
        >
          <Plus className="w-3 h-3" /> إضافة
        </button>
      </div>
    </div>
  );
}

// ── Matches Tab ───────────────────────────────────────────────────────────────
function MatchesTab() {
  const { toast } = useToast();
  const [editId, setEditId] = useState<number | null>(null);
  const [editData, setEditData] = useState<any>({});
  const [showAdd, setShowAdd] = useState(false);
  const [newMatch, setNewMatch] = useState<any>({ status: "upcoming", score1: 0, score2: 0, streamUrls: [] });

  const { data: matches, isLoading } = useQuery<MatchWithRelations[]>({
    queryKey: ["/api/admin/matches"],
    queryFn: () => adminFetch("/api/admin/matches"),
  });
  const { data: games } = useQuery<Game[]>({ queryKey: ["/api/games"] });
  const { data: teams } = useQuery<Team[]>({ queryKey: ["/api/teams"] });

  const updateMut = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) =>
      adminFetch(`/api/admin/matches/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/admin/matches"] }); setEditId(null); toast({ title: "تم التحديث" }); },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const deleteMut = useMutation({
    mutationFn: (id: number) => adminFetch(`/api/admin/matches/${id}`, { method: "DELETE" }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/admin/matches"] }); toast({ title: "تم الحذف" }); },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const addMut = useMutation({
    mutationFn: (data: any) => adminFetch("/api/admin/matches", { method: "POST", body: JSON.stringify(data) }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/admin/matches"] }); setShowAdd(false); setNewMatch({ status: "upcoming", score1: 0, score2: 0, streamUrls: [] }); toast({ title: "تمت الإضافة" }); },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const startEdit = (m: MatchWithRelations) => {
    setEditId(m.id);
    setEditData({ score1: m.score1, score2: m.score2, status: m.status, tournament: m.tournament, streamUrls: m.streamUrls ?? [] });
  };

  if (isLoading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-primary w-8 h-8" /></div>;

  const statusColors: Record<string, string> = {
    live: "bg-green-500/20 text-green-400 border-green-500/30",
    finished: "bg-white/8 text-white/40 border-white/10",
    upcoming: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between mb-4">
        <p className="text-white/50 text-sm">{matches?.length ?? 0} مباراة</p>
        <button
          onClick={() => setShowAdd(!showAdd)}
          className="flex items-center gap-2 bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30 px-4 py-2 rounded-xl text-sm font-bold transition"
          data-testid="button-add-match"
        >
          <Plus className="w-4 h-4" /> إضافة مباراة
        </button>
      </div>

      {/* Add form */}
      {showAdd && (
        <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-3 mb-4">
          <h3 className="text-white font-bold text-sm">مباراة جديدة</h3>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-white/50 text-xs mb-1 block">اللعبة</label>
              <select value={newMatch.gameId ?? ""} onChange={e => setNewMatch({ ...newMatch, gameId: Number(e.target.value) })}
                className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none">
                <option value="">اختر</option>
                {games?.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-white/50 text-xs mb-1 block">البطولة</label>
              <input value={newMatch.tournament ?? ""} onChange={e => setNewMatch({ ...newMatch, tournament: e.target.value })}
                className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none" placeholder="اسم البطولة" />
            </div>
            <div>
              <label className="text-white/50 text-xs mb-1 block">الفريق 1</label>
              <select value={newMatch.team1Id ?? ""} onChange={e => setNewMatch({ ...newMatch, team1Id: Number(e.target.value) })}
                className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none">
                <option value="">اختر</option>
                {teams?.filter(t => !newMatch.gameId || t.gameId === newMatch.gameId).map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-white/50 text-xs mb-1 block">الفريق 2</label>
              <select value={newMatch.team2Id ?? ""} onChange={e => setNewMatch({ ...newMatch, team2Id: Number(e.target.value) })}
                className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none">
                <option value="">اختر</option>
                {teams?.filter(t => !newMatch.gameId || t.gameId === newMatch.gameId).map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-white/50 text-xs mb-1 block">التاريخ والوقت</label>
              <input type="datetime-local" value={newMatch.startTime ?? ""} onChange={e => setNewMatch({ ...newMatch, startTime: new Date(e.target.value).toISOString() })}
                className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none" />
            </div>
            <div>
              <label className="text-white/50 text-xs mb-1 block">الحالة</label>
              <select value={newMatch.status} onChange={e => setNewMatch({ ...newMatch, status: e.target.value })}
                className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none">
                <option value="upcoming">قادمة</option>
                <option value="live">مباشر</option>
                <option value="finished">منتهية</option>
              </select>
            </div>
            <div>
              <label className="text-white/50 text-xs mb-1 block">نتيجة 1</label>
              <input type="number" min={0} value={newMatch.score1} onChange={e => setNewMatch({ ...newMatch, score1: Number(e.target.value) })}
                className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none" />
            </div>
            <div>
              <label className="text-white/50 text-xs mb-1 block">نتيجة 2</label>
              <input type="number" min={0} value={newMatch.score2} onChange={e => setNewMatch({ ...newMatch, score2: Number(e.target.value) })}
                className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none" />
            </div>
          </div>
          {/* Stream URLs */}
          <div className="col-span-2">
            <StreamUrlsInput
              urls={newMatch.streamUrls ?? []}
              onChange={urls => setNewMatch({ ...newMatch, streamUrls: urls })}
            />
          </div>
          <div className="flex gap-2 justify-end mt-2">
            <button onClick={() => setShowAdd(false)} className="px-4 py-2 rounded-xl text-white/50 hover:text-white text-sm transition">إلغاء</button>
            <button onClick={() => addMut.mutate(newMatch)} disabled={addMut.isPending}
              className="px-4 py-2 bg-primary text-white rounded-xl text-sm font-bold flex items-center gap-2 transition">
              {addMut.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />} حفظ
            </button>
          </div>
        </div>
      )}

      {/* Match list */}
      <div className="space-y-2">
        {matches?.map(m => (
          <div key={m.id} className="bg-white/5 border border-white/8 rounded-2xl p-4" data-testid={`card-match-${m.id}`}>
            {editId === m.id ? (
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-white/50 text-xs mb-1 block">البطولة</label>
                    <input value={editData.tournament} onChange={e => setEditData({ ...editData, tournament: e.target.value })}
                      className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none" />
                  </div>
                  <div>
                    <label className="text-white/50 text-xs mb-1 block">الحالة</label>
                    <select value={editData.status} onChange={e => setEditData({ ...editData, status: e.target.value })}
                      className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none">
                      <option value="upcoming">قادمة</option>
                      <option value="live">مباشر</option>
                      <option value="finished">منتهية</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-white/50 text-xs mb-1 block">نتيجة {m.team1.name}</label>
                    <input type="number" min={0} value={editData.score1} onChange={e => setEditData({ ...editData, score1: Number(e.target.value) })}
                      className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none" />
                  </div>
                  <div>
                    <label className="text-white/50 text-xs mb-1 block">نتيجة {m.team2.name}</label>
                    <input type="number" min={0} value={editData.score2} onChange={e => setEditData({ ...editData, score2: Number(e.target.value) })}
                      className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none" />
                  </div>
                </div>
                {/* Stream URLs */}
                <StreamUrlsInput
                  urls={editData.streamUrls ?? []}
                  onChange={urls => setEditData({ ...editData, streamUrls: urls })}
                />
                <div className="flex gap-2 justify-end">
                  <button onClick={() => setEditId(null)} className="p-2 rounded-lg text-white/40 hover:text-white transition"><X className="w-4 h-4" /></button>
                  <button onClick={() => updateMut.mutate({ id: m.id, data: editData })} disabled={updateMut.isPending}
                    className="p-2 rounded-lg bg-primary/20 text-primary hover:bg-primary/30 transition">
                    {updateMut.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <p className="text-white/40 text-xs mb-1">{m.game.name} · {m.tournament}</p>
                  <div className="flex items-center gap-2">
                    <span className="text-white text-sm font-bold truncate">{m.team1.name}</span>
                    <span className="text-white/60 text-sm font-mono font-bold">{m.score1} – {m.score2}</span>
                    <span className="text-white text-sm font-bold truncate">{m.team2.name}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className={`text-xs px-2 py-0.5 rounded-full border ${statusColors[m.status]}`}>
                      {m.status === "live" ? "مباشر" : m.status === "finished" ? "منتهية" : "قادمة"}
                    </span>
                    <span className="text-white/30 text-xs">{format(new Date(m.startTime), "dd/MM HH:mm")}</span>
                    {m.streamUrls && m.streamUrls.length > 0 && (
                      <span className="flex items-center gap-0.5 text-[10px] text-red-400/80 font-bold">
                        <Tv2 className="w-2.5 h-2.5" /> {m.streamUrls.length} بث
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={() => startEdit(m)} className="p-2 rounded-lg text-white/40 hover:text-white transition" data-testid={`button-edit-match-${m.id}`}>
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button onClick={() => deleteMut.mutate(m.id)} disabled={deleteMut.isPending}
                    className="p-2 rounded-lg text-white/40 hover:text-red-400 transition" data-testid={`button-delete-match-${m.id}`}>
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Games Tab ─────────────────────────────────────────────────────────────────
function GamesTab() {
  const { toast } = useToast();
  const [editId, setEditId] = useState<number | null>(null);
  const [editData, setEditData] = useState<any>({});
  const [showAdd, setShowAdd] = useState(false);
  const [newGame, setNewGame] = useState({ name: "", imageUrl: "" });

  const { data: games, isLoading } = useQuery<Game[]>({ queryKey: ["/api/games"] });

  const addMut = useMutation({
    mutationFn: (data: any) => adminFetch("/api/admin/games", { method: "POST", body: JSON.stringify(data) }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/games"] }); setShowAdd(false); setNewGame({ name: "", imageUrl: "" }); toast({ title: "تمت الإضافة" }); },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const updateMut = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => adminFetch(`/api/admin/games/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/games"] }); setEditId(null); toast({ title: "تم التحديث" }); },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const deleteMut = useMutation({
    mutationFn: (id: number) => adminFetch(`/api/admin/games/${id}`, { method: "DELETE" }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/games"] }); toast({ title: "تم الحذف" }); },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  if (isLoading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-primary w-8 h-8" /></div>;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between mb-4">
        <p className="text-white/50 text-sm">{games?.length ?? 0} لعبة</p>
        <button onClick={() => setShowAdd(!showAdd)}
          className="flex items-center gap-2 bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30 px-4 py-2 rounded-xl text-sm font-bold transition"
          data-testid="button-add-game">
          <Plus className="w-4 h-4" /> إضافة لعبة
        </button>
      </div>

      {showAdd && (
        <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-3 mb-4">
          <h3 className="text-white font-bold text-sm">لعبة جديدة</h3>
          <div className="grid grid-cols-1 gap-3">
            <div>
              <label className="text-white/50 text-xs mb-1 block">اسم اللعبة</label>
              <input value={newGame.name} onChange={e => setNewGame({ ...newGame, name: e.target.value })}
                className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none" placeholder="مثال: Valorant" />
            </div>
            <div>
              <label className="text-white/50 text-xs mb-1 block">رابط الصورة</label>
              <input value={newGame.imageUrl} onChange={e => setNewGame({ ...newGame, imageUrl: e.target.value })}
                className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none" placeholder="https://..." />
            </div>
          </div>
          <div className="flex gap-2 justify-end mt-2">
            <button onClick={() => setShowAdd(false)} className="px-4 py-2 rounded-xl text-white/50 hover:text-white text-sm transition">إلغاء</button>
            <button onClick={() => addMut.mutate(newGame)} disabled={addMut.isPending}
              className="px-4 py-2 bg-primary text-white rounded-xl text-sm font-bold flex items-center gap-2 transition">
              {addMut.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />} حفظ
            </button>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {games?.map(g => (
          <div key={g.id} className="bg-white/5 border border-white/8 rounded-2xl p-4 flex items-center gap-3" data-testid={`card-game-${g.id}`}>
            <img src={g.imageUrl} alt={g.name} className="w-8 h-8 object-contain rounded" onError={e => { (e.target as HTMLImageElement).style.display = "none"; }} />
            {editId === g.id ? (
              <div className="flex-1 flex gap-2">
                <input value={editData.name} onChange={e => setEditData({ ...editData, name: e.target.value })}
                  className="flex-1 bg-white/8 border border-white/12 rounded-lg px-3 py-1.5 text-white text-sm outline-none" />
                <input value={editData.imageUrl} onChange={e => setEditData({ ...editData, imageUrl: e.target.value })}
                  className="flex-1 bg-white/8 border border-white/12 rounded-lg px-3 py-1.5 text-white text-sm outline-none" placeholder="URL الصورة" />
                <button onClick={() => updateMut.mutate({ id: g.id, data: editData })} className="p-1.5 rounded-lg bg-primary/20 text-primary"><Check className="w-4 h-4" /></button>
                <button onClick={() => setEditId(null)} className="p-1.5 rounded-lg text-white/40 hover:text-white"><X className="w-4 h-4" /></button>
              </div>
            ) : (
              <>
                <span className="flex-1 text-white font-medium text-sm">{g.name}</span>
                <button onClick={() => { setEditId(g.id); setEditData({ name: g.name, imageUrl: g.imageUrl }); }}
                  className="p-2 text-white/40 hover:text-white transition" data-testid={`button-edit-game-${g.id}`}><Pencil className="w-4 h-4" /></button>
                <button onClick={() => deleteMut.mutate(g.id)}
                  className="p-2 text-white/40 hover:text-red-400 transition" data-testid={`button-delete-game-${g.id}`}><Trash2 className="w-4 h-4" /></button>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Teams Tab ─────────────────────────────────────────────────────────────────
function TeamsTab() {
  const { toast } = useToast();
  const [editId, setEditId] = useState<number | null>(null);
  const [editData, setEditData] = useState<any>({});
  const [showAdd, setShowAdd] = useState(false);
  const [newTeam, setNewTeam] = useState({ name: "", logoUrl: "", gameId: 0 });

  const { data: teams, isLoading } = useQuery<Team[]>({ queryKey: ["/api/teams"] });
  const { data: games } = useQuery<Game[]>({ queryKey: ["/api/games"] });

  const gameMap = Object.fromEntries((games ?? []).map(g => [g.id, g.name]));

  const addMut = useMutation({
    mutationFn: (data: any) => adminFetch("/api/admin/teams", { method: "POST", body: JSON.stringify(data) }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/teams"] }); setShowAdd(false); setNewTeam({ name: "", logoUrl: "", gameId: 0 }); toast({ title: "تمت الإضافة" }); },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const updateMut = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => adminFetch(`/api/admin/teams/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/teams"] }); setEditId(null); toast({ title: "تم التحديث" }); },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const deleteMut = useMutation({
    mutationFn: (id: number) => adminFetch(`/api/admin/teams/${id}`, { method: "DELETE" }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/teams"] }); toast({ title: "تم الحذف" }); },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  if (isLoading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-primary w-8 h-8" /></div>;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between mb-4">
        <p className="text-white/50 text-sm">{teams?.length ?? 0} فريق</p>
        <button onClick={() => setShowAdd(!showAdd)}
          className="flex items-center gap-2 bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30 px-4 py-2 rounded-xl text-sm font-bold transition"
          data-testid="button-add-team">
          <Plus className="w-4 h-4" /> إضافة فريق
        </button>
      </div>

      {showAdd && (
        <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-3 mb-4">
          <h3 className="text-white font-bold text-sm">فريق جديد</h3>
          <div className="grid grid-cols-1 gap-3">
            <div>
              <label className="text-white/50 text-xs mb-1 block">اسم الفريق</label>
              <input value={newTeam.name} onChange={e => setNewTeam({ ...newTeam, name: e.target.value })}
                className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none" placeholder="اسم الفريق" />
            </div>
            <div>
              <label className="text-white/50 text-xs mb-1 block">رابط الشعار</label>
              <input value={newTeam.logoUrl} onChange={e => setNewTeam({ ...newTeam, logoUrl: e.target.value })}
                className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none" placeholder="https://..." />
            </div>
            <div>
              <label className="text-white/50 text-xs mb-1 block">اللعبة</label>
              <select value={newTeam.gameId} onChange={e => setNewTeam({ ...newTeam, gameId: Number(e.target.value) })}
                className="w-full bg-white/8 border border-white/12 rounded-lg px-3 py-2 text-white text-sm outline-none">
                <option value={0}>اختر لعبة</option>
                {games?.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
              </select>
            </div>
          </div>
          <div className="flex gap-2 justify-end mt-2">
            <button onClick={() => setShowAdd(false)} className="px-4 py-2 rounded-xl text-white/50 hover:text-white text-sm transition">إلغاء</button>
            <button onClick={() => addMut.mutate(newTeam)} disabled={addMut.isPending}
              className="px-4 py-2 bg-primary text-white rounded-xl text-sm font-bold flex items-center gap-2 transition">
              {addMut.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />} حفظ
            </button>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {teams?.map(t => (
          <div key={t.id} className="bg-white/5 border border-white/8 rounded-2xl p-4 flex items-center gap-3" data-testid={`card-team-${t.id}`}>
            <img src={t.logoUrl} alt={t.name} className="w-8 h-8 object-contain rounded" onError={e => { (e.target as HTMLImageElement).style.display = "none"; }} />
            {editId === t.id ? (
              <div className="flex-1 flex gap-2 flex-wrap">
                <input value={editData.name} onChange={e => setEditData({ ...editData, name: e.target.value })}
                  className="flex-1 min-w-[120px] bg-white/8 border border-white/12 rounded-lg px-3 py-1.5 text-white text-sm outline-none" placeholder="الاسم" />
                <input value={editData.logoUrl} onChange={e => setEditData({ ...editData, logoUrl: e.target.value })}
                  className="flex-1 min-w-[160px] bg-white/8 border border-white/12 rounded-lg px-3 py-1.5 text-white text-sm outline-none" placeholder="URL الشعار" />
                <button onClick={() => updateMut.mutate({ id: t.id, data: editData })} className="p-1.5 rounded-lg bg-primary/20 text-primary"><Check className="w-4 h-4" /></button>
                <button onClick={() => setEditId(null)} className="p-1.5 rounded-lg text-white/40 hover:text-white"><X className="w-4 h-4" /></button>
              </div>
            ) : (
              <>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium text-sm truncate">{t.name}</p>
                  <p className="text-white/40 text-xs">{gameMap[t.gameId ?? 0] ?? "—"}</p>
                </div>
                <button onClick={() => { setEditId(t.id); setEditData({ name: t.name, logoUrl: t.logoUrl }); }}
                  className="p-2 text-white/40 hover:text-white transition" data-testid={`button-edit-team-${t.id}`}><Pencil className="w-4 h-4" /></button>
                <button onClick={() => deleteMut.mutate(t.id)}
                  className="p-2 text-white/40 hover:text-red-400 transition" data-testid={`button-delete-team-${t.id}`}><Trash2 className="w-4 h-4" /></button>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Main Admin Page ───────────────────────────────────────────────────────────
export default function AdminPage() {
  const [token, setToken] = useState(getToken());
  const [tab, setTab] = useState<"matches" | "games" | "teams">("matches");
  const [syncing, setSyncing] = useState(false);
  const { toast } = useToast();

  const handleSync = async () => {
    setSyncing(true);
    try {
      const res = await adminFetch("/api/admin/sync", { method: "POST" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/matches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/matches"] });
      toast({ title: `✅ تمت المزامنة — ${res.count} مباراة محمّلة` });
    } catch (e: any) {
      toast({ title: "خطأ في المزامنة", description: e.message, variant: "destructive" });
    } finally { setSyncing(false); }
  };

  const logout = () => { localStorage.removeItem(TOKEN_KEY); setToken(""); };

  if (!token) return <LoginScreen onLogin={setToken} />;

  const tabs = [
    { id: "matches" as const, label: "المباريات", icon: Trophy },
    { id: "games"   as const, label: "الألعاب",   icon: Gamepad2 },
    { id: "teams"   as const, label: "الفرق",     icon: Users },
  ];

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur border-b border-white/8">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-primary" />
            <span className="font-bold text-white">لوحة الإدارة</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleSync}
              disabled={syncing}
              className="flex items-center gap-1.5 bg-white/8 hover:bg-white/12 border border-white/10 px-3 py-1.5 rounded-xl text-sm text-white transition"
              data-testid="button-sync"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${syncing ? "animate-spin" : ""}`} />
              مزامنة
            </button>
            <button onClick={logout} className="text-white/40 hover:text-white text-sm px-2 py-1.5 transition" data-testid="button-logout">
              خروج
            </button>
          </div>
        </div>
        {/* Tabs */}
        <div className="max-w-2xl mx-auto px-4 flex gap-1 pb-2">
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-bold transition ${
                tab === t.id ? "bg-primary/20 text-primary" : "text-white/50 hover:text-white"
              }`}
              data-testid={`tab-${t.id}`}
            >
              <t.icon className="w-4 h-4" />
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 py-6">
        {tab === "matches" && <MatchesTab />}
        {tab === "games"   && <GamesTab />}
        {tab === "teams"   && <TeamsTab />}
      </div>
    </div>
  );
}
