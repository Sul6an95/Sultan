import { format } from "date-fns";
import { X, ExternalLink, Trophy, Zap, TrendingUp } from "lucide-react";
import type { MatchWithRelations } from "@shared/schema";

interface Props {
  match: MatchWithRelations;
  isOpen: boolean;
  onClose: () => void;
}

const MOCK_FORM: Record<number, string[]> = {};
function getForm(id: number): string[] {
  if (!MOCK_FORM[id]) {
    const opts = ["W","W","L","W","L","W","W","D","W","L"];
    MOCK_FORM[id] = Array.from({length:5},(_,i)=>opts[(id*3+i)%opts.length]);
  }
  return MOCK_FORM[id];
}

export function MatchDetailModal({ match, isOpen, onClose }: Props) {
  if (!isOpen || !match) return null;

  const isLive     = match.status === "live";
  const isFinished = match.status === "finished";
  const isUpcoming = match.status === "upcoming";

  const team1Won = isFinished && match.score1 > match.score2;
  const team2Won = isFinished && match.score2 > match.score1;

  const form1 = getForm(match.team1.id);
  const form2 = getForm(match.team2.id);

  const h2h = {
    t1: (match.team1.id % 3) + 2,
    draw: 1,
    t2: ((match.team1.id + match.team2.id) % 3),
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end justify-center"
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="bg-[#111118] border border-white/10 rounded-t-3xl w-full max-w-lg max-h-[92vh] overflow-y-auto shadow-2xl">

        {/* Drag handle */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-white/20" />
        </div>

        {/* Header */}
        <div className="sticky top-0 z-10 bg-[#111118]/95 backdrop-blur-sm px-5 py-3 flex items-center justify-between border-b border-white/8">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-6 h-6 rounded-lg overflow-hidden bg-white/10 flex items-center justify-center flex-shrink-0">
              {match.game.imageUrl && (
                <img src={match.game.imageUrl} alt={match.game.name} className="w-full h-full object-contain p-0.5" />
              )}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white/90 truncate">{match.tournament}</p>
              <p className="text-[10px] text-white/40">{match.game.name}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-xl transition-colors flex-shrink-0" data-testid="button-close-modal">
            <X className="w-4.5 h-4.5 text-white/60" />
          </button>
        </div>

        <div className="px-5 pb-8 space-y-6 pt-5">

          {/* ── Score Hero ─────────────────────────────────────────────── */}
          <div className="flex items-center gap-4">
            {/* Team 1 */}
            <div className="flex-1 flex flex-col items-center gap-2">
              <div className={`w-18 h-18 rounded-2xl overflow-hidden border-2 flex items-center justify-center p-1.5 ${
                team1Won ? "border-primary bg-primary/10" : "border-white/15 bg-white/6"
              }`} style={{width:72,height:72}}>
                {match.team1.logoUrl ? (
                  <img src={match.team1.logoUrl} alt={match.team1.name} className="w-full h-full object-contain" />
                ) : (
                  <span className="text-xl font-bold text-white/70">{match.team1.name.substring(0,2)}</span>
                )}
              </div>
              <p className={`text-sm font-bold text-center leading-tight ${team1Won ? "text-white" : "text-white/70"}`}>
                {match.team1.name}
              </p>
            </div>

            {/* Score */}
            <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
              {isLive && (
                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-500/15 border border-red-500/30">
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
                  <span className="text-[10px] font-bold text-red-400 tracking-wide">LIVE</span>
                </div>
              )}
              {(isLive || isFinished) ? (
                <div className="px-5 py-2 bg-white/6 border border-white/10 rounded-2xl">
                  <span className="text-3xl font-black text-white tabular-nums">
                    {match.score1} — {match.score2}
                  </span>
                </div>
              ) : (
                <div className="flex flex-col items-center">
                  <span className="text-2xl font-black text-white/80">VS</span>
                  <span className="text-xs text-white/40 mt-1">{format(new Date(match.startTime), "HH:mm")}</span>
                </div>
              )}
              {isFinished && <span className="text-[10px] font-semibold text-white/35 uppercase tracking-wide">Full Time</span>}
            </div>

            {/* Team 2 */}
            <div className="flex-1 flex flex-col items-center gap-2">
              <div className={`rounded-2xl overflow-hidden border-2 flex items-center justify-center p-1.5 ${
                team2Won ? "border-primary bg-primary/10" : "border-white/15 bg-white/6"
              }`} style={{width:72,height:72}}>
                {match.team2.logoUrl ? (
                  <img src={match.team2.logoUrl} alt={match.team2.name} className="w-full h-full object-contain" />
                ) : (
                  <span className="text-xl font-bold text-white/70">{match.team2.name.substring(0,2)}</span>
                )}
              </div>
              <p className={`text-sm font-bold text-center leading-tight ${team2Won ? "text-white" : "text-white/70"}`}>
                {match.team2.name}
              </p>
            </div>
          </div>

          {/* ── Form ───────────────────────────────────────────────────── */}
          <div className="bg-white/4 border border-white/8 rounded-2xl p-4">
            <p className="text-[10px] font-bold text-white/40 uppercase tracking-wider mb-3">Last 5 Matches</p>
            <div className="flex items-center justify-between">
              <div className="flex gap-1.5">
                {form1.map((r, i) => (
                  <FormBadge key={i} result={r} />
                ))}
              </div>
              <span className="text-[10px] text-white/25 font-bold mx-2">FORM</span>
              <div className="flex gap-1.5">
                {form2.map((r, i) => (
                  <FormBadge key={i} result={r} />
                ))}
              </div>
            </div>
          </div>

          {/* ── Head to Head ───────────────────────────────────────────── */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Trophy className="w-4 h-4 text-primary" />
              <p className="text-xs font-bold text-white/60 uppercase tracking-wider">Head to Head</p>
            </div>
            <div className="bg-white/4 border border-white/8 rounded-2xl overflow-hidden">
              <div className="grid grid-cols-3 divide-x divide-white/8">
                <div className="py-4 text-center">
                  <p className="text-2xl font-black text-white">{h2h.t1}</p>
                  <p className="text-[10px] text-white/40 mt-0.5 truncate px-1">{match.team1.name}</p>
                </div>
                <div className="py-4 text-center bg-white/3">
                  <p className="text-2xl font-black text-white/50">{h2h.draw}</p>
                  <p className="text-[10px] text-white/30 mt-0.5">Draws</p>
                </div>
                <div className="py-4 text-center">
                  <p className="text-2xl font-black text-white">{h2h.t2}</p>
                  <p className="text-[10px] text-white/40 mt-0.5 truncate px-1">{match.team2.name}</p>
                </div>
              </div>
              {/* Win bar */}
              <div className="h-1 flex">
                <div className="bg-primary h-full transition-all" style={{width: `${(h2h.t1/(h2h.t1+h2h.draw+h2h.t2))*100}%`}} />
                <div className="bg-white/20 h-full" style={{width: `${(h2h.draw/(h2h.t1+h2h.draw+h2h.t2))*100}%`}} />
                <div className="bg-primary/60 h-full flex-1" />
              </div>
            </div>
          </div>

          {/* ── Streams ────────────────────────────────────────────────── */}
          {match.streamUrls && match.streamUrls.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-primary" />
                <p className="text-xs font-bold text-white/60 uppercase tracking-wider">Watch Live</p>
              </div>
              <div className="space-y-2">
                {match.streamUrls.map((url, idx) => {
                  const isTwitch = url.includes("twitch");
                  const isYT = url.includes("youtube");
                  const label = isTwitch ? "Twitch" : isYT ? "YouTube" : "Live Stream";
                  const color = isTwitch ? "bg-purple-600/20 border-purple-500/30 text-purple-300"
                              : isYT    ? "bg-red-600/20 border-red-500/30 text-red-300"
                              : "bg-primary/15 border-primary/30 text-primary";
                  return (
                    <a key={idx} href={url} target="_blank" rel="noopener noreferrer"
                       className={`flex items-center justify-between p-3.5 rounded-xl border transition-all hover:opacity-80 ${color}`}
                       data-testid={`link-stream-${idx}`}>
                      <span className="font-semibold text-sm">{label}</span>
                      <ExternalLink className="w-4 h-4 opacity-70" />
                    </a>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function FormBadge({ result }: { result: string }) {
  const styles = {
    W: "bg-green-500/25 text-green-400 border-green-500/40",
    L: "bg-red-500/25 text-red-400 border-red-500/40",
    D: "bg-yellow-500/25 text-yellow-400 border-yellow-500/40",
  }[result] ?? "bg-white/10 text-white/40 border-white/20";

  return (
    <div className={`w-7 h-7 rounded-lg border text-[11px] font-black flex items-center justify-center ${styles}`}>
      {result}
    </div>
  );
}
