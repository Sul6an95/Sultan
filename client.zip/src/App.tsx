import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

// Pages
import MatchesPage from "./pages/Matches";
import NewsPage from "./pages/News";
import LeaguesPage from "./pages/Leagues";
import FollowingPage from "./pages/Following";
import SearchPage from "./pages/Search";
import AdminPage from "./pages/Admin";

function Router() {
  return (
    <Switch>
      <Route path="/" component={MatchesPage} />
      <Route path="/news" component={NewsPage} />
      <Route path="/leagues" component={LeaguesPage} />
      <Route path="/following" component={FollowingPage} />
      <Route path="/search" component={SearchPage} />
      <Route path="/admin" component={AdminPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
